%USDATA  construct US time series 1901-2010 and extract samples for
%        estimation in mle*.m.
%
%        Measures constructed:
%
%           Y     = GNP - Sales tax 
%                       - Military compensation 
%                       + Services and depreciation of durables
%           C     = Consumer nondurables (CND) plus services (CS)
%                       - Portion of sales tax for CND&CS
%                       + Services and depreciation of durables
%           X     = Gross private domestic investment (fixed+inventory)
%                       + Government investment
%                       + Consumer durables (CD) 
%                       - Portion of sales tax for CD 
%                       - Military equipment 
%                       - 1/2 military facilities
%                       + Net factor payments
%           K     = Capital stock corresponding to X
%           G     = Government consumption
%                       - Military compensation 
%                       + Military equipment 
%                       + 1/2 military facilities
%                       + Net exports in goods and services
%           P     = GNP deflator
%           H     = Civilian manhours  
%           P16   = Population over 16
%

%        Ellen McGrattan, 2-16-02
%        Revised, ERM, 2-8-05
%        Revised, Alice Schoonbroodt, 09-03-12

load data/kenn_us.dat
load data/kenr_us.dat
load data/mhrs_us.dat
load data/popu_us.dat
load data/na115.dat
load data/na175.dat
load data/na176.dat
load data/na305.dat
load data/na395.dat
load data/na566a.dat
load data/na566b.dat
load data/na602a.dat
load data/na602b.dat
load data/na602c.dat
load data/na602d.dat
load data/na605a.dat
load data/na603a.dat
load data/na605b.dat
load data/na605c.dat
load data/na605d.dat
load data/na608a.dat
load data/na608b.dat
load data/na608c.dat
load data/na608d.dat
load data/na609b.dat
load data/na609c.dat
load data/na609d.dat
load data/fa11.dat
load data/fa71a.dat
load data/fa71b.dat
load data/fa15.dat
load data/fa75a.dat
load data/fa75b.dat

%
% Adjust series to common units
%
na602a         = na602a/1000;
na602b         = na602b/1000;
na602c         = na602c/1000;
na602d         = na602d/1000;
na603a         = na603a/1000;
na605a         = na605a/1000000;
na605b         = na605b/1000000;
na605c         = na605c/1000000;
na605d         = na605d/1000000;
na608a         = na608a/1000000;
na608b         = na608b/1000000;
na608c         = na608c/1000000;
na608d         = na608d/1000000;
na609b         = na609b/1000 *1.1;
na609c         = na609c/1000 *1.1;
na609d         = na609d/1000 *1.1;
na566          = [na566a(1:2,:),na566b(1:2,2:14)]; % in 2005 chained dollars
na605          = [na605a([1:4,80],1:19),na605b([1:4,81],1:39), ...
                                        na605c([1:4,81],:), ...
                                        na605d([1:4,81],2:11)];
na608          = [na608a([1:4,80],1:19),na608b([1:4,81],1:39), ...
                                        na608c([1:4,81],:), ...
                                        na608d([1:4,81],2:11)];
na609          = [NaN*ones(4,19),na609b(1:4,1:39),na609c(1:4,:),na609d(1:4,2:11);
                  NaN*ones(1,19),1700*[na605b(81,1:39),na605c(81,:),na605d(81,2:11)]];
kenn_us        = kenn_us/1000;
mhrs_us        = mhrs_us/1000;
popu_us        = popu_us/1000000;
fa15(11,1:13)  = zeros(1,13);
fa75           = zeros(76,110);
fa75(19,1:96) = fa75a(19,:);
fa75(19,97:110)= fa75b(21,:);
fa75(26,1:96) = fa75a(26,:);
fa75(26,97:110)= fa75b(28,:);
fa75(30,1:96) = fa75a(30,:);
fa75(30,97:110)= fa75b(32,:);
t               = [1901:2010]';

%
% Population
% Sources: Historical Statistics, Colonial to 1970, Series A6-8
%          Economic Report of the President 2001, Table B-34
%          Economic Report of the President 2012, Table B-34
%
T      = 113:222;
p16    = popu_us(T,5);

%
% Pre-1929 National Accounts
% Source: Kendrick (1961)   
%
T      = 113:141;   % 1901--1929
NA     = NaN*ones(71,1);
kc     = [kenn_us(T,2);NA];
kgpdf  = [kenn_us(T,3);NA];
kgpdi  = [kenn_us(T,4);NA];
knfi   = [kenn_us(T,5);NA];
kg     = [kenn_us(T,6);NA];
kgnp   = [kenn_us(T,7);NA];
krgnp  = [kenr_us(T,7);NA];
krgpdi = [kenr_us(T,4);NA];

%
% Post-1929 National Accounts
% Source: NIPA at www.bea.doc.gov (downloaded 6/24/02)
%
T      = 1:82;     % 1929--2010 
NA     = NaN*ones(28,1);
nrgnp  = [NA;na176(5,T)'];
nrgpdi = [NA;na566(2,T)'];
ngnp   = [NA;na175(5,T)'];
ngdp   = [NA;na115(2,T)'];
nc     = [NA;na115(3,T)'];
ncd    = [NA;na115(5,T)'];
ncnd   = [NA;na115(6,T)'];
ncs    = [NA;na115(7,T)'];
nipd   = [NA;na115(8,T)'];
ngpdf  = [NA;na115(9,T)'];
ngpdi  = [NA;na115(14,T)'];
nnx    = [NA;na115(15,T)'];
nnxe   = [NA;na115(16,T)'];
nnxi   = [NA;na115(19,T)'];
ng     = [NA;na115(22,T)'];
ngc    = [NA;na395(3,T)'];
ngi    = [NA;na395(4,T)'];
ngims  = [NA;na395(15,T)'];
ngime  = [NA;na395(16,T)'];
nnfi   = ngnp-ngdp+nnx;
nfac   = ngnp-ngdp;
nstx   = [zeros(28,1);sum(na305([4,15,32],T))'];
nmilc  = [zeros(1,28),na603a(80,:).*na602a(76,:)./na603a(76,:), ...
                      na602b(81,2:40),na602c(81,2:14),na602d(81,2:11)]';

%
% Pre-1947 Manhours
% Source: Kendrick (1961)   
%
T      = 113:210;
kh     = [mhrs_us(T,3);NaN;NaN];

%
% Post-1947 Manhours
% Source: NIPA at www.bea.doc.gov (downloaded 08/29/12)
%
T      = 1:82;     % 1929--2010 
NA     = NaN*ones(28,1);
nh     = [NA;
          na609(2,T)'.*(1+(na608(2,T)-na605(2,T))'./na605(2,T)') - ...
          na609(5,T)'.*(1+(na608(5,T)-na605(5,T))'./na605(5,T)')];

%
% Investments and Capital Stocks 
% Source: Fixed Assets at www.bea.doc.gov (downloaded 08/30/12)
%
igpdf  = fa15(4,:)';
icd    = fa15(14,:)';
igi    = sum(fa15(11:13,:))';
igime  = fa75(19,:)';
igims  = fa75(26,:)';
igimf  = fa75(30,:)';

cgpdf  = [NaN*ones(24,1);fa11(4,:)'];
ccd    = [NaN*ones(24,1);fa11(14,:)'];
cgi    = [NaN*ones(24,1);fa11(9,:)'];
cgime  = [NaN*ones(24,1);fa71a(19,:)';fa71b(21,:)'];
cgims  = [NaN*ones(24,1);fa71a(26,:)';fa71b(28,:)'];
cgimf  = [NaN*ones(24,1);fa71a(30,:)';fa71b(32,:)'];

dgpdf  = NaN*ones(110,1);
dcd    = dgpdf;
dgi    = dgpdf;
dgime  = dgpdf;
dgims  = dgpdf;
dgimf  = dgpdf;
for i =110:-1:26;
  dgpdf(i)  = -cgpdf(i)+cgpdf(i-1)+igpdf(i);
  dcd(i)    = -ccd(i)  +ccd(i-1)  +icd(i);
  dgi(i)    = -cgi(i)  +cgi(i-1)  +igi(i);
  dgime(i)  = -cgime(i)+cgime(i-1)+igime(i);
  dgims(i)  = -cgims(i)+cgims(i-1)+igims(i);
  dgimf(i)  = -cgimf(i)+cgimf(i-1)+igimf(i);
end;
drgpdf = avgnan(dgpdf./cgpdf);
drcd   = avgnan(dcd./ccd);
drgi   = avgnan(dgi./cgi);
drgime = avgnan(dgime./cgime);
drgims = avgnan(dgims./cgims);
drgimf = avgnan(dgimf./cgimf);
drnfi  = drgpdf;
drfac  = drgpdf;

for i =24:-1:1;
  cgpdf(i)  = (cgpdf(i+1)-igpdf(i+1))/(1-drgpdf);
  ccd(i)    = (ccd(i+1)  -icd(i+1)  )/(1-drcd*.9575);
  cgi(i)    = (cgi(i+1)  -igi(i+1)  )/(1-drgi);
  cgime(i)  = (cgime(i+1)-igime(i+1))/(1-drgime);
  cgims(i)  = (cgims(i+1)-igims(i+1))/(1-drgims);
  cgimf(i)  = (cgimf(i+1)-igimf(i+1))/(1-drgimf);
end;
for i =25:-1:2;
  dcd(i)    = -ccd(i)  +ccd(i-1)  +icd(i);
end;
dcd(1) = dcd(2);

%
% Combine data to obtain long time series:
%

rgnp   = [krgnp(1:29)*nrgnp(29)/krgnp(29); nrgnp(30:110)];
rgpdi  = [krgpdi(1:29)*nrgpdi(29)/krgpdi(29); nrgpdi(30:110)];
gnp    = [kgnp(1:28); ngnp(29:110)];
stx    = nstx;
milc   = nmilc;
c      = [kc(1:28);    nc(29:110)];
cd     = [icd(1:28);   ncd(29:110)];
g      = [kg(1:28);    ng(29:110)];
gi     = [igi(1:28);   ngi(29:110)];
gime   = [igime(1:28); ngime(29:110)];
gimf   = [igimf(1:28); igimf(29:110)];
gpdf   = [kgpdf(1:28); ngpdf(29:110)];
gpdi   = [kgpdi(1:28); ngpdi(29:110)];
nfi    = [knfi(1:28);  nnfi(29:110)];
fac    = [.005*kgnp(1:28); ngnp(29:110)-ngdp(29:110)];
nx     = nfi-fac;
h      = [kh(1:47);    nh(48:110)];
gc     = g-gi;

crgpdi(100)  = 1507.1;
for i =99:-1:1;
  crgpdi(i)  = crgpdi(i+1)-rgpdi(i+1);
end;

for i =101:1:110;
  crgpdi(i)  = crgpdi(i-1)+rgpdi(i-1);
end;

cnfi(1)     = 0;
cfac(1)     = 0;
for i = 2:110;
  cnfi(i)   = cnfi(i-1)*(1-drnfi)+nfi(i);
  cfac(i)   = cfac(i-1)*(1-drfac)+fac(i);
end;
crgpdi = crgpdi(:);
cnfi   = cnfi(:);
cfac   = cfac(:);
bgpdf  = [(cgpdf(1)-igpdf(1))/(1-drgpdf);cgpdf(1:109)];
bcd    = [(ccd(1)  -icd(1))  /(1-drcd);  ccd(1:109)];
bgi    = [(cgi(1)  -igi(1))  /(1-drgi);  cgi(1:109)];
bgime  = [(cgime(1)-igime(1))/(1-drgime);cgime(1:109)];
bgims  = [(cgims(1)-igims(1))/(1-drgims);cgims(1:109)];
bgimf  = [(cgimf(1)-igimf(1))/(1-drgimf);cgimf(1:109)];
brgpdi = [(crgpdi(1)-rgpdi(1))          ;crgpdi(1:109)];
bnfi   = [(cnfi(1) -nfi(1))  /(1-drnfi); cnfi(1:109)];
bfac   = [(cfac(1) -fac(1))  /(1-drfac); cfac(1:109)];

%
% Measures to match growth model analogues:
%
P      = gnp./rgnp;
Y      = gnp -stx -milc +.04*ccd +dcd;
C      = (c-cd)  -(c-cd)./c .*stx +.04*ccd +dcd;
X      = gpdf +gpdi +fac +gi -gime -.5*gimf +cd -cd./c .*stx;
K      = bgpdf +P.*brgpdi +bfac +bgi -bgime -.5*bgimf +bcd;
G      = gc -milc +gime +.5*gimf + nx;
H      = h;
P16    = p16;
L      = (H./P16)/5000;
lam    = 1.016.^(t-1901);
Ypc    = Y./(P.*P16);
Cpc    = C./(P.*P16);
Xpc    = X./(P.*P16);
Gpc    = G./(P.*P16);
Kpc    = K./(P.*P16);

psi    = 2.24;
theta  = 0.35;
A      = Ypc./(Kpc.^theta .* L.^(1-theta));           % Ellen uses A for detrended TFP, I call detrended TFP DA
LP     = Ypc./L;

uszvar1= [t,Ypc/Ypc(29)*lam(29),Xpc/Ypc(29)*lam(29),L, ...
            Gpc/Ypc(29)*lam(29),Kpc/Ypc(29)*lam(29)];
uszvar2= [t,Ypc/Ypc(79)*lam(25),Xpc/Ypc(79)*lam(25),L, ...
            Gpc/Ypc(79)*lam(25),Kpc/Ypc(79)*lam(25)];
disp(['Year, Output, Investment, Labor, Government Spending, ', ...
      'Beginning-of-Period Capital 1901-2000'])
disp(sprintf(' %4g %7.4f %7.4f %7.4f %7.4f %7.4f\n',uszvar1'))
disp(' ')
disp(['Year, Output, Investment, Labor, Government Spending, ', ...
      'Beginning-of-Period Capital 1955-2000'])
disp(sprintf(' %4g %7.4f %7.4f %7.4f %7.4f %7.3f\n',uszvar2(55:100,:)'))

DY     = Ypc./lam*lam(29);
DK     = Kpc./lam*lam(29);
DA     = DY./(DK.^theta .* L.^(1-theta));               % detrended TFP, in Ellen's code this was called A, for me A is regular TFP
taun   = 1- (psi/(1-theta)) *(Cpc./Ypc) .* (L./(1-L));
long   = [t,log(A),1-taun];


